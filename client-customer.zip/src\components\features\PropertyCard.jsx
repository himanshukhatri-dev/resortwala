import React, { useState } from 'react';
import { FaStar, FaHeart, FaMapMarkerAlt, FaChevronLeft, FaChevronRight, FaWifi, FaSwimmingPool, FaParking, FaSnowflake, FaBed, FaBath, FaUserFriends, FaExchangeAlt } from 'react-icons/fa';

import { Link, useNavigate } from 'react-router-dom';
import { useWishlist } from '../../context/WishlistContext';
import { useCompare } from '../../context/CompareContext';
import { toast } from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';

export default function PropertyCard({ property, searchParams }) {
    const [currentImageIndex, setCurrentImageIndex] = useState(0);

    const {
        id = property?.PropertyId || property?.id,
        name = property?.Name || property?.name || "Luxury Villa",
        location = property?.Location || property?.CityName || "India",
        price = parseFloat(property?.Price || property?.PricePerNight || property?.ResortWalaRate || 0) || 15000,
        rating = property?.Rating || 4.9,
        description = property?.LongDescription || property?.long_description || "Experience luxury living in this beautiful property featuring modern amenities and stunning views.",
    } = property || {};

    // Collect all available images
    const allImages = [
        ...(property?.images?.map(img => img.image_url || img.image_path) || []),
        property?.primary_image?.image_url || property?.primary_image?.image_path,
        property?.ImageUrl || property?.image_url || property?.image_path,
        "https://images.unsplash.com/photo-1613490493576-7fde63acd811?q=80&w=1000",
        "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=1000",
        "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1000"
    ].filter(Boolean);

    const images = allImages.slice(0, 5); // Limit to 5 for the slider

    const nextImage = (e) => {
        e.stopPropagation();
        setCurrentImageIndex((prev) => (prev + 1) % images.length);
    };

    const prevImage = (e) => {
        e.stopPropagation();
        setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
    };

    const buildQuery = () => {
        if (!searchParams) return "";
        const params = new URLSearchParams();
        if (searchParams.dates?.start) params.set('start', searchParams.dates.start);
        if (searchParams.dates?.end) params.set('end', searchParams.dates.end);
        const guests = searchParams.guests || {};
        if (guests.adults) params.set('adults', guests.adults);
        if (guests.children) params.set('children', guests.children);
        return params.toString();
    };

    const queryString = buildQuery();
    const navigate = useNavigate();
    const { isWishlisted, toggleWishlist } = useWishlist();
    const { toggleCompare, compareList } = useCompare();
    const active = id ? isWishlisted(id) : false;

    const handleCardClick = (e) => {
        window.open(`/property/${id}?${queryString}`, '_blank');
    };


    const handleWishlist = async (e) => {
        e.stopPropagation();
        if (!id) return;
        const result = await toggleWishlist(id);
        if (result.success) toast.success(result.message);
        else toast.error(result.message);
    };

    return (
        <div
            onClick={handleCardClick}
            className="group flex flex-col xl:flex-row gap-5 bg-white rounded-[1.5rem] overflow-hidden border border-gray-100 p-3 cursor-pointer relative hover:shadow-[0_20px_60px_-15px_rgba(0,0,0,0.1)] hover:-translate-y-1 transition-all duration-300"
        >
            {/* IMAGE SLIDER (Left Side) - Increased Height (~15%) */}
            <div className="relative w-full xl:w-[300px] h-[276px] xl:h-[300px] flex-shrink-0 rounded-[1.2rem] overflow-hidden bg-gray-100">
                <AnimatePresence mode="wait">
                    <motion.img
                        key={currentImageIndex}
                        src={images[currentImageIndex]}
                        alt={name}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="w-full h-full object-cover"
                    />
                </AnimatePresence>

                {/* COMPARE BUTTON */}
                <div
                    onClick={(e) => { e.stopPropagation(); toggleCompare(property); }}
                    className={`absolute top-4 left-4 z-10 w-9 h-9 rounded-full flex items-center justify-center transition-all backdrop-blur-md cursor-pointer shadow-sm ${compareList?.find(p => p.id === id || p.PropertyId === id)
                        ? 'bg-black text-white'
                        : 'bg-white/70 text-gray-700 hover:bg-white hover:text-black'
                        }`}
                    title="Compare"
                >
                    <FaExchangeAlt size={12} />
                </div>

                {/* HEART BUTTON */}
                <div
                    onClick={handleWishlist}
                    className={`absolute top-4 right-4 z-10 w-9 h-9 rounded-full flex items-center justify-center transition-all backdrop-blur-md ${active ? 'bg-red-500 text-white' : 'bg-white/70 text-gray-700 hover:bg-white hover:text-red-500'}`}
                >
                    <FaHeart className={active ? "fill-current" : "text-lg"} />
                </div>

                {/* SLIDER CONTROLS */}
                <div className="absolute inset-0 flex items-center justify-between px-3 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={prevImage} className="w-7 h-7 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center text-gray-800 hover:bg-white transition-all shadow-md">
                        <FaChevronLeft size={10} />
                    </button>
                    <button onClick={nextImage} className="w-7 h-7 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center text-gray-800 hover:bg-white transition-all shadow-md">
                        <FaChevronRight size={10} />
                    </button>
                </div>

                {/* DOTS */}
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
                    {images.map((_, i) => (
                        <div
                            key={i}
                            className={`h-1 rounded-full transition-all ${i === currentImageIndex ? 'w-3 bg-white' : 'w-1 bg-white/50'}`}
                        />
                    ))}
                </div>

                {(property?.PropertyType || property?.IsTrending) && (
                    <div className="absolute top-3 left-3 flex flex-col gap-2 items-start">
                        {/* PROPERTY TYPE BADGE - REMOVED (Moved to content area) */}

                        {/* TRENDING BADGE */}
                        {property?.IsTrending && (
                            <div className="bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-lg text-[9px] font-black text-white uppercase tracking-wider flex items-center gap-1.5 shadow-lg border border-white/10">
                                <div className="w-1.5 h-1.5 rounded-full bg-yellow-400 animate-pulse" /> Popular
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* CONTENT (Right Side) */}
            <div className="flex-1 flex flex-col pt-1 pb-1 pr-2">
                <div>
                    {/* ROW 1: Title Only */}
                    <div className="mb-2">
                        <h3 className="text-xl md:text-2xl font-bold text-gray-900 font-serif leading-tight line-clamp-2" title={name}>
                            {name}
                        </h3>
                    </div>

                    {/* ROW 2: Property Type, Rating & Location (Moved Below Title) */}
                    <div className="flex flex-wrap items-center gap-3 mb-2 text-sm">
                        {/* PROPERTY TYPE BADGE - Moved Here */}
                        {property?.PropertyType && (
                            <div className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border ${property.PropertyType === 'Waterpark'
                                ? 'bg-blue-50 text-blue-700 border-blue-100'
                                : 'bg-purple-50 text-purple-700 border-purple-100'
                                }`}>
                                {property.PropertyType}
                            </div>
                        )}

                        <div className="flex items-center gap-1.5 font-bold text-gray-900 bg-gray-50 px-2 py-0.5 rounded-md border border-gray-100">
                            <FaStar className="text-yellow-400 text-xs mb-0.5" />
                            <span>{rating}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-gray-500 font-medium">
                            <FaMapMarkerAlt className="text-gray-400" size={12} />
                            <span className="truncate max-w-[200px]">{location}</span>
                        </div>
                    </div>

                    <p className="text-gray-500 text-sm md:text-base leading-relaxed line-clamp-2 mb-2 max-w-2xl">
                        {description}
                    </p>

                    {/* QUICK STATS & AMENITIES */}
                    <div className="flex flex-col gap-2 mb-2">
                        {/* Quick Stats Row */}
                        <div className="flex items-center gap-6 text-sm text-gray-700 font-medium">
                            <div className="flex items-center gap-2">
                                <FaUserFriends className="text-gray-400" />
                                <span>{property?.MaxGuests || 6} Guests</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <FaBed className="text-gray-400" />
                                <span>{property?.Bedrooms || 3} Bedroom</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <FaBath className="text-gray-400" />
                                <span>{property?.Bathrooms || 3} Bath</span>
                            </div>
                        </div>

                        {/* Amenities Tags */}
                        <div className="flex flex-wrap gap-2">
                            <div className="flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-blue-700 rounded-lg text-xs font-bold">
                                <FaSwimmingPool size={10} /> Pool
                            </div>
                            <div className="flex items-center gap-1.5 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-lg text-xs font-bold">
                                <FaWifi size={10} /> Wi-Fi
                            </div>
                            <div className="flex items-center gap-1.5 px-3 py-1 bg-sky-50 text-sky-700 rounded-lg text-xs font-bold">
                                <FaSnowflake size={10} /> AC
                            </div>
                        </div>
                    </div>
                </div>


                <div className="flex items-center justify-between border-t border-gray-50 pt-4 mt-auto">
                    <div className="flex items-center gap-3">
                        <div className="flex -space-x-2 overflow-hidden">
                            {[1, 2, 3].map(i => (
                                <img
                                    key={i}
                                    className="inline-block h-8 w-8 rounded-full ring-2 ring-white"
                                    src={`https://i.pravatar.cc/100?img=${i + 10}`}
                                    alt=""
                                />
                            ))}
                        </div>
                        <div className="text-xs font-bold text-gray-600">
                            <span className="text-gray-900 font-extrabold">+12 people</span> booked recently
                        </div>
                    </div>

                    <div className="flex flex-col items-end gap-2">
                        <div className="text-right">
                            <span className="text-2xl font-bold text-gray-900 font-sans">₹{price.toLocaleString()}</span>
                            <span className="text-[10px] font-normal text-gray-400 opacity-60 ml-0.5">/ night</span>
                        </div>
                        <button className="px-6 py-3 bg-white border-2 border-gray-100 text-gray-900 rounded-xl font-bold text-sm hover:border-black hover:bg-black hover:text-white transition-all shadow-sm active:scale-95">
                            View Details
                        </button>
                    </div>
                </div>
            </div>

        </div>
    );
}

