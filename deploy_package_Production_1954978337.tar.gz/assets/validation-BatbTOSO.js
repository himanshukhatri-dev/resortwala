const t=r=>{if(!r)return"";let e=r.replace(/[\s-]/g,"");return e=e.replace(/^\+91/,""),e=e.replace(/^0/,""),e},a=r=>{if(!r)return!1;const e=t(r);return/^[0-9]{10}$/.test(e)};export{a as i,t as n};
