import{S as r,T as t}from"./index-xPfIvPdm.js";var a=r();const e=t(a);export{e as R,a as r};
